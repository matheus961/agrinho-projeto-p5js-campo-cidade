function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(220);

  // Divisão entre cidade e campo
  let middle = width / 2;

  // Desenhar a cidade (à esquerda)
  drawCity(0, middle);

  // Desenhar o campo de agricultura (à direita)
  drawFarm(middle, width);
}

function drawCity(xStart, xEnd) {
  // Céu da cidade (tom poluído)
  fill(169, 169, 169); // Céu cinza
  noStroke();
  rect(xStart, 0, xEnd - xStart, height * 0.5);

  // Desenhar os prédios
  fill(128, 128, 128); // Cor dos prédios
  for (let i = xStart + 30; i < xEnd - 50; i += 90) {
    rect(i, height * 0.3, 60, height * 0.5);
  }

  // Janelas dos prédios
  fill(255, 255, 255); // Cor das janelas
  for (let i = xStart + 30; i < xEnd - 50; i += 90) {
    for (let j = 0; j < 3; j++) {
      rect(i + 15, height * 0.3 + j * 50, 20, 30);
    }
  }

  // Rua da cidade
  fill(100, 100, 100); // Cor da rua
  rect(xStart, height * 0.8, xEnd - xStart, height * 0.2);

  // Faixa de pedestre
  fill(255);
  for (let i = xStart + 40; i < xEnd - 50; i += 60) {
    rect(i, height * 0.85, 40, 10);
  }

  // Carros na rua
  drawCar(xStart + 40, height * 0.85);
  drawCar(xStart + 150, height * 0.85);
  drawCar(xStart + 250, height * 0.85);
}

function drawCar(x, y) {
  fill(255, 0, 0); // Cor do carro
  rect(x, y, 50, 20); // Corpo do carro

  fill(0, 0, 0); // Cor das rodas
  ellipse(x + 15, y + 20, 15, 15);
  ellipse(x + 35, y + 20, 15, 15);
}

function drawFarm(xStart, xEnd) {
  // Céu do campo (mais claro e limpo)
  fill(135, 206, 235); // Céu azul claro
  noStroke();
  rect(xStart, 0, xEnd - xStart, height * 0.5);

  // Campo de agricultura (plantação)
  fill(34, 139, 34); // Cor da grama
  rect(xStart, height * 0.5, xEnd - xStart, height * 0.5);

  // Linhas de plantação (cultivo)
  stroke(0, 128, 0); // Cor das linhas de plantação
  for (let i = 50; i < width; i += 100) {
    line(i, height * 0.7, i + 50, height * 0.7);
    line(i, height * 0.75, i + 50, height * 0.75);
    line(i, height * 0.8, i + 50, height * 0.8);
  }

  // Árvores no campo (agora com mais árvores)
  drawTree(xStart + 100, height * 0.6);
  drawTree(xStart + 200, height * 0.65);
  drawTree(xStart + 300, height * 0.7);
  drawTree(xStart + 400, height * 0.75);
  drawTree(xStart + 500, height * 0.8);
  drawTree(xStart + 600, height * 0.7);
  drawTree(xStart + 700, height * 0.6);
  drawTree(xStart + 150, height * 0.55);
  drawTree(xStart + 250, height * 0.6);
  drawTree(xStart + 350, height * 0.65);

  // Trator (agricultura)
  drawTractor(xStart + 500, height * 0.85);
}

function drawTree(x, y) {
  // Tronco da árvore
  fill(139, 69, 19);
  rect(x, y - 40, 20, 40);

  // Folhagem
  fill(0, 128, 0);
  ellipse(x + 10, y - 60, 50, 50);
}

function drawTractor(x, y) {
  // Corpo do trator
  fill(255, 215, 0); // Cor amarela do trator
  rect(x, y - 20, 60, 20);

  // Rodas do trator
  fill(0, 0, 0); // Cor das rodas
  ellipse(x + 15, y, 20, 20);
  ellipse(x + 45, y, 20, 20);

  // Cabine do trator
  fill(100, 100, 100);
  rect(x + 20, y - 40, 30, 20);

  // Detalhes adicionais
  fill(0, 0, 0);
  rect(x + 35, y - 40, 10, 10); // Janela da cabine
}
